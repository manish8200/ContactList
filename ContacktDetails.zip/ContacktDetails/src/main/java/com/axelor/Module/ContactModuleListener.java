package com.axelor.Module;

import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.Module;
import com.google.inject.servlet.GuiceServletContextListener;

public class ContactModuleListener extends GuiceServletContextListener{

	@Override
	protected Injector getInjector() {
		return Guice.createInjector((Iterable<? extends Module>) new ContactModule());	}
}
//Guice.createInjector(new JpaPersistModule("persistence"),new ContactModule());