package com.axelor.Module;

import com.axelor.controller.ContactBook;
import com.axelor.service.ContactService;
import com.axelor.service.ContactServiceImpl;
import com.google.inject.servlet.ServletModule;

public class ContactModule extends ServletModule {
	
	
	@Override 
	protected void configureServlets() {
		
		serve("/contactbook").with(ContactBook.class);
	
		bind(ContactService.class).to(ContactServiceImpl.class);
		
		
	}
}


