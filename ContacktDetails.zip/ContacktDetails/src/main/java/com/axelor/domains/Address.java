package com.axelor.domains;

public class Address {

}
