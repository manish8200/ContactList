package com.axelor.service;

public interface AddressService {

	
	
	
	
}
