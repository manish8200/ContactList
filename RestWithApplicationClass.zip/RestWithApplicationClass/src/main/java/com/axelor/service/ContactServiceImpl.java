package com.axelor.service;

import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.axelor.Entity.ContactDetails;



public class ContactServiceImpl implements ContactService {
	
	@Inject
	EntityManager entityManager;
	
	
	

	@Override
	public void addContact(String fullname, String mobileno) {

		//EntityManager entityManager = getConnection();

		entityManager.getTransaction().begin();

		ContactDetails contactDetails = new ContactDetails();
		contactDetails.setFullName(fullname);
		contactDetails.setMobileNo(mobileno);

		entityManager.persist(contactDetails);

		entityManager.getTransaction().commit();

	}

	@Override
	public void deleteContact(int cid) {
	//	EntityManager entityManager = getConnection();
		entityManager.getTransaction().begin();
		Query query = entityManager.createQuery("delete from ContactDetails where cid =:cid");
		query.setParameter("cid", cid);
		query.executeUpdate();
		entityManager.getTransaction().commit();

	}

	@Override
	public void updateContact(int cid, String fullname, String mobileno) {

		//EntityManager entityManager = getConnection();
		entityManager.getTransaction().begin();

		Query query = entityManager.createQuery("update ContactDetails set fullName=:fullname , mobileNo =:mobileno where cid=:id");
		query.setParameter("fullname", fullname);
		query.setParameter("mobileno", mobileno);
		query.setParameter("id", cid);

		query.executeUpdate();
		entityManager.getTransaction().commit();

	}

	@Override
	public int CheckContact(String fullname) {
	//	EntityManager entityManager = getConnection();
		int count = 0;
		entityManager.getTransaction().begin();
		Query query = entityManager.createQuery("from ContactDetails where fullname=:name");
		query.setParameter("name", fullname);
		List result = query.getResultList();

		for (Object p : result) {
			count = count + 1;
		}
		// System.out.println("result vaalues" + cou);
		return count;
	}

	@Override
	public List<ContactDetails> getAllcontacts() {
	//	EntityManager entityManager = getConnection();

		Query query = entityManager.createQuery("from ContactDetails");

		List al = query.getResultList();
		
			System.out.println("Caller test..............................!!!!");
	

		return al;

	}

	@Override
	public ContactDetails getContactDetailsById(int id) {
		//EntityManager entityManager = getConnection();
		
		Query query = entityManager.createQuery("from ContactDetails where cid =:id");
		query.setParameter("id", id);
		ContactDetails contactDetails = (ContactDetails) query.getSingleResult();

		return contactDetails;
	}

	@Override
	public ContactDetails getContactDetailsByName(String fullName) {
		Query query = entityManager.createQuery("select c from contactdetails c");
		//query.setParameter("name", fullName);
		ContactDetails contactDetails = (ContactDetails) query.getSingleResult();
		System.out.println(fullName);
		return contactDetails;

	}
	

//	@Override
//	public void addAddress(int id, String address) {
//		// TODO Auto-generated method stub
//		entityManager.getTransaction().begin();
//		ContactDetails cd = new ContactDetails();
//		cd.setCid(id);
//
//		ManageAddress ma = new ManageAddress();
//		ma.setAddress(address);
//		ma.setCd(cd);
//
//		entityManager.persist(ma);
//		entityManager.getTransaction().commit();
//	}
//
//	@Override
//	public List<ManageAddress> update(int cid) {
//		// TODO Auto-generated method stub
//		System.out.println("Address Impliment Cid " + cid);
//		//EntityManager entityManager = getConnection();
//		Query query = entityManager.createQuery("from ManageAddress  where cd_cid=:id ");
//		query.setParameter("id", cid);
//	List<ManageAddress> result= query.getResultList();
//		for (ManageAddress m : result)
//		{
//			System.out.println(m.getAddress() + "" + m.getAid());
//		}
//		
//		
//		return result;
//	}
//
//	@Override
//	public void updateAddress(int aid, String address) {
//		// TODO Auto-generated method stub
//		entityManager.getTransaction().begin();
//
//		Query query = entityManager
//				.createQuery("update ManageAddress set Address=:add  where Aid=:id");
//		query.setParameter("id",aid);
//		query.setParameter("add", address);
//		
//
//		query.executeUpdate();
//		entityManager.getTransaction().commit();
//	}
//
//	@Override
//	public List<ManageAddress> updateById(int cid) {
//		// TODO Auto-generated method stub
//		Query query = entityManager.createQuery("from ManageAddress  where Aid=:id ");
//		query.setParameter("id", cid);
//	List<ManageAddress> result= query.getResultList();
//		for (ManageAddress m : result)
//		{
//			System.out.println(m.getAddress() + "" + m.getAid());
//		}
//		
//		
//		return result;
//	}
}
