package com.axelor.service;

import java.util.List;

import com.axelor.Entity.ContactDetails;

public interface ContactService {

	void addContact(String fullname, String mobileno);

	void updateContact(int cid, String fullname, String mobileno);

	List<ContactDetails> getAllcontacts();
	
	void deleteContact(int id);

	ContactDetails getContactDetailsById(int id);

	int CheckContact(String fullname);
	
	ContactDetails getContactDetailsByName(String fullName);
	
//	void addAddress(int id,String address);
//	List<ManageAddress> update(int cid);
//	void updateAddress(int aid,String address);
//	List<ManageAddress> updateById(int cid);

}
