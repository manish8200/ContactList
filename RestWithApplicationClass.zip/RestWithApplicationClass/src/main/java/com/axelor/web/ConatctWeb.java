package com.axelor.web;


import java.io.IOException;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;

import com.axelor.Entity.ContactDetails;
import com.axelor.service.ContactService;

@Singleton
@Path("/")
public class ConatctWeb {

	@Inject ContactService cs;
	@Context HttpServletRequest rq;
	@Context HttpServletResponse rs;
	String action;
	
	//@Inject
	//EntityManager em;
	
	@POST
	@Path("/addcontacts")
	public void addContact(@FormParam("fullname") String name, @FormParam("mobileno") String mobileno) throws ServletException, IOException {
		cs.addContact(name, mobileno);
		List cd = (List) cs.getAllcontacts();
		rq.setAttribute("name", cd);
		System.out.println(cd);
		rq.getRequestDispatcher("/contactlist.jsp").forward(rq, rs);
	}
	
	@POST
	@Path("/update")
	public void updateMethod(@FormParam("contactid") int id, @FormParam("fullname") String name , @FormParam("mobileno") String mobileno) throws ServletException, IOException {
		
		cs.updateContact(id, name, mobileno);	
		rq.getRequestDispatcher("/contactlist.jsp").forward(rq, rs);
		
		List cd = (List) cs.getAllcontacts();
		rq.setAttribute("name", cd);
		System.out.println(cd);
		
		
		System.out.println(name +" "+ mobileno);
		System.out.println("hello word");
		
		}
	
	@GET
	
	@Path("/delete/{cid}")
	public void deletemethod(@PathParam("cid") int cid) throws ServletException, IOException {
		
		System.err.println(cid);

		cs.deleteContact(cid);
		rq.getRequestDispatcher("/contactlist.jsp").forward(rq, rs);
		List cd = (List) cs.getAllcontacts();
		rq.setAttribute("name", cd);
		System.out.println(cd);
	}
	
	@GET
	@Path("/CheckConatct")
	public void CheckMethod(@PathParam("fullname") String name) {
		cs.CheckContact(name);
	}
	@GET
	@Path("/listContact")
	public void getAllContactsMethod(@PathParam("id") int id) throws ServletException, IOException {
		//cs.getAllcontacts();
		System.err.println("demo test...............!!!!!!!!!!!!!!!");

		
		List cd = (List) cs.getAllcontacts();
		rq.setAttribute("name", cd);
		System.out.println(cd);
		
		rq.getRequestDispatcher("/contactlist.jsp").forward(rq, rs);
		
		
	}
	@GET
	@Path("/Listbyid/{cid}")
	public void getDetailsByidMethod(@PathParam("cid") int cid) throws ServletException, IOException {
		//cs.getContactDetailsById(cid);
		ContactDetails contactDetails = cs.getContactDetailsById(cid);
		rq.setAttribute("name", contactDetails);
		
		
		rq.getRequestDispatcher("/SaveAddress.jsp").forward(rq, rs);
		List cd = (List) cs.getAllcontacts();
		rq.setAttribute("name", cd);
		System.out.println(cd);
		
		
		
	}
	
	@GET
	@Path("/search")
	public void getDetailsByNameMethod(@FormParam("name") String name) throws ServletException, IOException {
		//cs.getContactDetailsById(cid);
		ContactDetails contactDetails = cs.getContactDetailsByName(name);
		rq.setAttribute("name", contactDetails);
		rq.getRequestDispatcher("/Contactlist.jsp").forward(rq, rs);
		
	}
}
