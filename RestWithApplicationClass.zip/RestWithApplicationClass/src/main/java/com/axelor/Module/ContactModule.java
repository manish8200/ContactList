package com.axelor.Module;

import com.axelor.service.ContactService;
import com.axelor.service.ContactServiceImpl;
import com.axelor.web.ConatctWeb;
import com.google.inject.AbstractModule;

public class ContactModule extends AbstractModule{

	@Override
	protected void configure() {
		// TODO Auto-generated method stub
	bind(ConatctWeb.class);
	bind(ContactService.class).to(ContactServiceImpl.class);
	}
}
